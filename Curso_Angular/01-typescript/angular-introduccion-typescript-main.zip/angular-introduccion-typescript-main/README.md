# Ejercicios introductorios a TypeScript

Para ejecutar el programa, sigan estos pasos:

1. Clonar o descargar el proyecto
2. Ejecutar ```npm install``` en la carpeta del proyecto
3. Cambiar en el ```main.ts```, el path del ejercicio que quieren ejecutar
4. Correr ```npm run dev``` para ejecutar el programa