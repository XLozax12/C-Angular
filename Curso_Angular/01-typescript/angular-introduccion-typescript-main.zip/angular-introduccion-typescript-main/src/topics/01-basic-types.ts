

const name: string = 'Strider';
let hpPoints: number | 'FULL' = 95;
const isAlive: boolean = true;


hpPoints = 'FULL';

console.log({
    name, hpPoints, isAlive
});



export {};